from fastapi import FastAPI
from pydantic import BaseModel
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch
import joblib
import numpy as np


label_encoder = joblib.load("label_encoder.joblib")

model = AutoModelForSequenceClassification.from_pretrained("bert_16/")
tokenizer = AutoTokenizer.from_pretrained("bert_16/")
model.eval()

app = FastAPI()


class TextInput(BaseModel):
    text: str

class PredictionOutput(BaseModel):
    mbti: str
    confidence_score: float

@app.post("/predict", response_model=PredictionOutput)
def predict_mbti(input: TextInput):
    inputs = tokenizer(input.text, return_tensors="pt", truncation=True, padding=True)
    with torch.no_grad():
        outputs = model(**inputs)
        logits = outputs.logits
        probs = torch.nn.functional.softmax(logits, dim=1)
        pred_class = torch.argmax(probs, dim=1).item()
        confidence = torch.max(probs).item()

    mbti_label = label_encoder.inverse_transform([pred_class])[0]
    return {
        "mbti": mbti_label,
        "confidence_score": float(confidence)
    }

@app.get("/")
def health_check():
    return {"status": "healthy"}